<?php

define('DB_USER','root');
define('DB_PASSWORD','root');
define('DB_DATABASE','carpool');
define('DB_SERVER','localhost');

?>